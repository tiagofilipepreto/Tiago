package pt.upacademy.exemplos;

public class FizzBuzz {
	private int numCicles;
	public static int test;

	public static void main(String[] args) {
		// TODO pergunte de um numero de 1 a 100
		FizzBuzz myApp = new FizzBuzz();
		
		System.out.println(myApp.numCicles);
		
		
	}

}
