package pt.upacademy.exemplos;

public class myApp {

	public static void main(String[] args) {
	FizzBuzz myFizz = new FizzBuzz();
	
	
	}

}
